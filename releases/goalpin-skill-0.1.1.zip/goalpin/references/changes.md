# Changes and roadmaps

Use this procedure for substantial work or edits to an existing artifact. Skip ceremony that does not change a decision.

## Establish the baseline

Inspect the smallest relevant resource set. Separate observed behavior from required behavior. Identify the correct file, record, application, or document, including its version or fresh observation. For creation, establish inputs and output requirements rather than inventing an existing baseline.

Retain a compact record:

- Current: relevant observed facts and evidence references.
- Desired: the result the user requested.
- Change: the necessary difference.
- Preserve: properties, behavior, content, and interactions that must survive.
- Acceptance: each material criterion, its origin, and how it can be checked.
- Unknowns: unresolved intent, evidence, assumptions, or capability.
- Scope: resources, permitted effects, and existing authorization.

Explicit user requirements and applicable constraints outrank implementation preferences. A clear authorized request can supply sufficient intent; a task record is not a new permission form.

## Guide work in any app

Apply this procedure using the agent's existing permitted tools, whether it works in a desktop app, browser, terminal, or connected service. A GoalPin app adapter is not required to guide the agent. Use a relevant specialist skill for application knowledge; keep this workflow responsible for intent, scope, progress, and verification. Do not claim runtime enforcement where only guidance is available.

Before each meaningful edit or consequential action, check:

1. Purpose: which requested outcome or necessary prerequisite does this action serve? Omit unrelated improvements.
2. Target: is this the intended app, window, document/project, and selected object or region? Reobserve after relevant context, selection, mode, or tool changes. Never reuse coordinates or an assumed selection across a changed state.
3. Extent: could the action affect a shared component, linked object, parent, global setting, or other work outside the intended target? Include indirect effects in the preservation check.
4. Expected result: what observable change should occur, and what must remain unchanged? If control behavior is unknown, inspect or consult relevant guidance instead of experimenting on the user's artifact.

Work in small coherent batches sized by what can be verified together. Do not force a screenshot or model review for every keystroke. Inspect after a batch and before dependent work; reobserve sooner when the target or mode changes. Keep the procedure proportional and preserve existing authorization.

If the result diverges from the requested outcome, stop the dependent sequence. Compare the observed difference with the task card, then make a scoped correction. Undo or restore only when it is known to affect the agent's own change and preserve intervening user work. Otherwise retain the evidence and ask the focused question needed to proceed.

## Long requests and incremental corrections

Extract a compact task card before substantial work: outcome and completion checks, requested targets and changes, exact must/must-not constraints, preservation requirements, latest user corrections, completed milestones, and next step. Keep detailed instructions/evidence accessible by reference; do not turn a summary into a replacement for exact values or unresolved requirements.

Use the card at each meaningful edit boundary instead of repeatedly resending the full prompt. A new user request such as "also add this" amends the relevant steps; it does not silently authorize rebuilding the whole artifact or dropping earlier requirements. Reconcile conflicts with prior instructions explicitly. Preserve verified progress and revise only affected work.

The same pattern applies when adding a screen while preserving existing screens and shared styles; editing one model object while preserving other objects, materials, and lighting; or changing one document section while preserving the rest. These are guidance examples, not claims of live validation in those apps.

## Ask questions that affect the result

Inspect accessible evidence before asking the user to describe it. Ask if missing information would change scope, correctness, authority, preservation, or a meaningful tradeoff. Use grounded alternatives where useful.

Examples: which of two discovered screens should change; which behavior should differ; whether an existing interaction must remain; which conflicting requirement has priority. Do not guess sensitive values or consequential authority. State low-impact assumptions where reasonable.

Preserve answers and existing authorization across turns. Work independently while an optional or required answer is pending, but do not execute steps that depend on a missing required answer. Elapsed time is not approval.

## Prepare the roadmap

For substantial work, show a short sequence linking each step to a requirement or prerequisite and a completion check. Include consequential choices before implementing them. For clear one-step work, an implicit plan is sufficient. Honor a plan-only request by stopping before implementation.

Execute the smallest scoped change. Do not add unrelated fixes to manufacture progress. A trusted user amendment changes the task version: invalidate affected actions, evidence, and checks while retaining unaffected verified work.

## Verify and report

Inspect the resulting saved artifact or authoritative state. Check required outcomes and protected properties, not just tool dispatch. Use existing checks when they cover the requirement, and rerun affected dependencies after a repair. Broaden checks when new evidence justifies it.

Complete only when every material required criterion is satisfied with appropriate evidence, including explicitly required subjective acceptance. Otherwise report partial verification, user judgment, missing input, or an environment boundary accurately. Do not discard an uncheckable requirement to declare success.
