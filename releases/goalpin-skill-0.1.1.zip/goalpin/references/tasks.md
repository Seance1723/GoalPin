# Task-specific checks

Load only the relevant part. Existing specialist skills remain useful; GoalPin coordinates scope and verification without replacing their domain expertise.

| Task | Relevant baseline | Result checks |
| --- | --- | --- |
| Explanation or conversation | Prompt, audience, requested depth, and necessary authoritative evidence | Address the question accurately at the requested depth; do not inspect a workspace without need |
| Research | Question, source requirements, freshness, known evidence and gaps | Support material claims with inspected appropriate sources; expose contradictions and inaccessible evidence |
| Coding | Reported behavior, nearby implementation, relevant interfaces and tests | Demonstrate corrected behavior and preservation of relevant existing behavior; do not rewrite requirements to pass |
| Writing | Audience, purpose, existing text, required facts, voice, and length | Preserve required meaning and facts; use an agreed rubric for subjective quality |
| Documents or design | Correct artifact, editability, layout, required content, supported fonts/assets and interactions | Inspect the saved native result; do not substitute a flattened appearance for required editable structure |
| Data analysis | Correct inputs, units, assumptions, provenance, and expected outputs | Reconcile calculations to source inputs; verify formulas, dimensions, and preservation of protected data |
| Browser or desktop, in any app | Current app/window/document, selection, mode, requested target, scope, and intended direct/indirect effects | Use the shared app-work checkpoints in changes.md; verify after coherent batches and before dependent edits; preserve unrelated work |

For Figma work, preserve editable text, components, and interactions; use browser-compatible fonts/assets. Validate browser rendering/editing when authorized and available. If verification is desktop-only, report the browser verification gap.

For Blender or another structured editing app, identify the intended project and object/region plus relevant selection or editing mode. Check the requested result and any protected linked objects, materials, lighting, animation, or other specified properties. Consult the app's specialist guidance when needed; do not assume that a successful click proves the requested artifact change.

These examples share one app-agnostic guidance process. Unsupported runtime interception does not prevent the skill from guiding authorized work through the host's existing tools. It does limit what the plugin can automatically block or independently verify.

Use deterministic value, calculation, schema, or artifact checks where they cover the requirement. Keep semantic judgments separate. Do not infer competence or execution protection for an unsupported domain merely because the common workflow applies.
