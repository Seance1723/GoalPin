# Runtime and token use

The portable skill guides behavior. The runtime can enforce restrictions only for actions it actually owns or intercepts. A connected MCP server does not control the host's unrelated mouse, shell, API, or other tool servers.

The guidance workflow is useful without an app-specific broker. For any app the host can already operate, apply the task card, pre-edit checks, bounded batches, and correction procedure through those existing permitted tools. Do not stop all work merely because the runtime lacks that app adapter, and do not describe guidance as automatic interception or guaranteed mistake prevention. Default delivery belongs to the agent host, independently of which app the task uses.

Use the runtime's task/version and evidence references rather than repeatedly sending full plans or captures. Task creation through agent-facing tools is a proposal; agent text cannot impersonate human authorization. Activation, model adherence, result verification, and enforceable execution are separate capabilities.

For supported actions, bind the exact target and arguments to the task version, check current relevant state, execute through the broker, and inspect the effect before dependent work. Reject stale or ambiguous targets. A previous permission or screenshot does not lock a changing page. Keep human control surfaces outside agent execution paths.

Reuse facts only while resource version, freshness, provenance, scope, and authority remain valid. Keep exact constraints, recipient identities, numbers, units, unresolved defects, and trusted amendments in compact state. A generated summary is not automatically lossless. A local summary also cannot remove conversation context a closed host continues to replay.

Prefer bounded relevant reads, compact successful receipts, evidence handles, local deterministic checks, and targeted verification. Retrieve full details when needed; do not silently truncate necessary evidence. Avoid routine reviewers, repeated roadmaps, and repeated discovery. Preserve the user's requested output and selected model.

For usage claims, count all execution, planning, review, correction, compaction, memory, and subagent calls, including failed attempts. Keep cached input, monetary cost, latency, and logical token volume separate. Missing material usage makes numerical savings unverified. Hold output quality, authority, and permitted human assistance constant; transferring work to the user is not equivalent autonomous savings.
