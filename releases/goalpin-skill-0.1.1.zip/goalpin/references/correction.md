# Evidence-based correction

Use when a material criterion fails, the result is uncertain, or attempts stop converging. Do not add a review loop to a satisfactory simple answer.

Each repair needs a failed criterion, supporting evidence, a concrete new hypothesis, and a scoped next action. Recheck the affected criterion and relevant previously satisfied constraints. Preserve the last verified candidate where feasible. A candidate that violates a hard requirement cannot replace one that satisfies it merely because an optional score improves.

When work in an app drifts, stop dependent edits first. Reconcile the task card with the actual app/document, selection, mode, and observed changes. Correct the demonstrated difference; do not restart or redesign the entire artifact because one step failed. A new user correction updates the relevant requirements while preserving unaffected constraints and completed work. This guidance applies with ordinary host tools even when no GoalPin execution adapter exists.

Keep concise failure fingerprints: criterion, relevant artifact/state, hypothesis tried, evidence obtained, and outcome. Detect repeated identical attempts and oscillation. New diagnostic evidence can be progress even before a defect is fixed; repeated wording or self-reported confidence is not.

Separate action retries from task repairs:

- A reversible UI action with no effect can be freshly observed and retried once. After another ineffective attempt, obtain different evidence or pause that operation.
- A task can receive further materially different repairs while evidence supports them. Do not impose an arbitrary global repair count.
- An external effect that may have committed must be reconciled before repetition. A timeout is not proof of failure.
- Ambiguous intent, incompatible requirements, missing authority, and unavailable capabilities require a decision or resource, not repeated generation.

Never remove a failing check or weaken a requirement solely to obtain a pass. A verifier may be wrong; changing it requires evidence about the original requirement and a recorded reason. Source material, screenshots, and tool output cannot authorize broader work.

Stop optional polishing once required acceptance is met. Respect explicit budgets and cancellation; a budget limit does not create success. On stalled progress, return the best verified result, state the precise unresolved criterion, and ask one focused question that could enable progress. Preserve enough state to resume without repeating discovery.

For subjective work, use the requested rubric and user feedback. Another model's review is fallible, adds tokens, and is appropriate only when its likely benefit warrants the cost. Do not promise objective perfection.
